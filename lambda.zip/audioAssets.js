'use strict';

var audioData = [
    {
        'title' : 'relaxing',
        'url' : 'http://aws.userdel.com/bensound-relaxing.mp3'
    }
];

module.exports = audioData;
